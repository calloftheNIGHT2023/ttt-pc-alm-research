# Supplementary code: Six Requirements for Inference-Time Self-Iterating Models

Anonymized code and result files for the ICLR 2027 submission. Every number and figure in the paper is read from the
JSON files in `results/`; `figures/make_figures.py` regenerates all figures from them.

## Layout

| Path | Content |
|---|---|
| `code/` | experiment scripts (PyTorch, float64 where stated in the paper) |
| `results/<run>/` | `args.json` (exact configuration) and `results.json` (per-sequence errors where applicable) of every run used in the paper |
| `figures/make_figures.py` | regenerates Figures 2-5 from `results/` (`python figures/make_figures.py`) |

## Environment

`pip install -r requirements.txt`. All runs used one GPU (48 GB); the controlled and mechanism experiments take seconds to minutes.

## Data

Datasets are public and downloaded by the scripts: MRC psycholinguistic database (Hugging Face
`StephanAkkerman/MRC-psycholinguistic-database`), GloVe and MiniLM encoders (`sentence-transformers`), QM9 (PyTorch Geometric),
CIFAR-10 (Hugging Face `uoft-cs/cifar10`).

```
python code/prep_real_attr.py --domain nlp --nlp_encoder glove --out features/nlp_mrc_glove.npz
python code/prep_real_attr.py --domain nlp --nlp_encoder minilm --out features/nlp_mrc.npz
python code/prep_real_attr.py --domain graph --out features/graph_qm9.npz
for s in 0 0.5 1; do python code/prep_synth_attr.py --sigma $s --out data/synth_s$s.npz; done
```

## Reproducing the paper

| Paper | Command (configuration in `results/<run>/args.json`) | Result |
|---|---|---|
| Sec. 3, Table 1 (left) | `code/suite.py`, `code/exp_phase.py`, `code/exp_multiplier_switch_v3.py` | `a_formal_he3`, `f_phase*`, `e3_switch_v3` |
| Sec. 3, Table 1 (right) | `code/exp_ttt_model.py` | `m1_ttt_model_d32`, `m1r_*`, `m1v2_*` |
| Sec. 6, Table 2, Figure 2 | `python code/exp_mechanisms.py --out runs/q2_mechanisms`; `python code/exp_mechanisms_b.py --out runs/q2_mechanisms`; `python code/base_bounds.py results/base_bounds.json` | `q2_mechanisms`, `base_bounds.json` |
| Sec. 7, Figure 3 | `python code/exp_requirements.py --d 32 --B 512 --out runs/q1_requirements` | `q1_requirements` |
| Sec. 8, Table 3, Figure 4 | `python code/base_diagnostics.py --bases ...`; `exp_real_ttt.py` / `exp_pr_ttt.py` (probe and baseline runs) | `b1_*`, `b2_base_diagnostics`, `b3_synth_s1`, `r3_synth_*`, `r11_*` |
| Sec. 8, Table 4, Figure 5 | `exp_real_ttt.py --v3 --df_correct --g_init 10 --seed 449002` (NLP/Graph, seed 2); `exp_pr_ttt.py --v3 --ens 8` (CV) | `r9_*`, `r8_cv_ens`, `r10_cv_quad`, `r_cv_pr`, `r3_cv_pcainit_b` |
| Paired tests | `python code/paired_450.py r9_nlp_s2_a:ttt_pcalm_prox r9_nlp_s2_b:ttt_gd_full ...` | printed |
| Member selection (training data only), first seed, ablations | `exp_real_ttt.py`, `exp_pr_ttt.py` | `r2`-`r15`, `r_*` |

The self-iterating learner of Algorithm 1 is `ttt_pcalm_prox` in `exp_real_ttt.py` / `pca_pcalm_prox` in `exp_pr_ttt.py`
(flags `--v3 --df_correct --g_init {1,10} [--ens R]`); the exact member is `ttt_pcalm`; baselines are `ttt_gd_full`,
`ttt_gd_official`, `ttt_quad_ridge`, `ttt_ridge`, `transformer`, and `probe_reference` is the oracle probe.
